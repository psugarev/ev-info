import SwiftUI
import SwiftData

// MARK: - Charging
// Live charging state, lifetime counters and the charging self-test. Kept apart
// from driving and from the tariff/cost screen.

struct ChargingView: View {
    @EnvironmentObject var telemetry: TelemetryEngine
    @EnvironmentObject var store: TelemetryStore

    @Query(sort: \BatterySnapshot.timestamp, order: .reverse)
    private var snapshots: [BatterySnapshot]

    private var counterSource: BatterySnapshot? {
        snapshots.first { $0.normalChargeCount != nil || $0.quickChargeCount != nil }
    }

    private var acCount: Int? {
        counterSource?.normalChargeCount ?? (telemetry.normalChargeCount > 0 ? telemetry.normalChargeCount : nil)
    }

    private var dcCount: Int? {
        counterSource?.quickChargeCount ?? (telemetry.quickChargeCount > 0 ? telemetry.quickChargeCount : nil)
    }

    private var acEnergy: Double? {
        counterSource?.normalChargeEnergyKWh ?? (telemetry.normalChargeEnergyKWh > 0 ? telemetry.normalChargeEnergyKWh : nil)
    }

    private var dcEnergy: Double? {
        counterSource?.quickChargeEnergyKWh ?? (telemetry.quickChargeEnergyKWh > 0 ? telemetry.quickChargeEnergyKWh : nil)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                liveCard
                countersCard
                diagnosticsCard
            }
            .padding(16)
            .padding(.bottom, 24)
        }
        .background(Theme.background)
        .navigationTitle("Charging")
        .settingsToolbar()
    }

    private var liveCard: some View {
        TelemetryCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    CardLabel(text: "CHARGING")
                    Spacer()
                    Text(telemetry.isCharging ? "CHARGING" : "NOT CHARGING")
                        .font(.system(size: 9, weight: .heavy, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(telemetry.isCharging ? Theme.green : Theme.textTertiary)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background((telemetry.isCharging ? Theme.green : Theme.textTertiary).opacity(0.12), in: Capsule())
                }

                HStack(alignment: .firstTextBaseline) {
                    Text(String(format: "%+.1f", telemetry.batteryPowerKW))
                        .font(.system(size: 44, weight: .bold, design: .rounded))
                        .monospacedDigit()
                        .foregroundStyle(telemetry.batteryPowerKW < 0 ? Theme.green : Theme.cyan)
                    Text("kW")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(Theme.textSecondary)
                    Spacer()
                    Text(String(format: "%.0f %%", telemetry.socPercent))
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                        .monospacedDigit()
                        .foregroundStyle(Theme.textPrimary)
                }

                HStack {
                    Label(String(format: "%.0f V", telemetry.batteryVoltageV), systemImage: "bolt.fill")
                    Spacer()
                    Label(String(format: "%.0f °C", telemetry.batteryTemperatureC), systemImage: "thermometer.medium")
                    Spacer()
                    Label(String(format: "%.1f V", telemetry.auxiliaryVoltageV), systemImage: "car.battery")
                }
                .font(.caption)
                .foregroundStyle(Theme.textSecondary)

                if !telemetry.isCharging {
                    Text("Plug in an AC or DC charger and run the charging test to validate the charging path.")
                        .font(.caption2)
                        .foregroundStyle(Theme.textTertiary)
                }
            }
        }
    }

    private var countersCard: some View {
        TelemetryCard {
            VStack(alignment: .leading, spacing: 12) {
                CardLabel(text: "LIFETIME")

                HStack(spacing: 0) {
                    stat("AC sessions", acCount.map(String.init) ?? "—")
                    Divider().frame(height: 30).overlay(Theme.border)
                    stat("DC sessions", dcCount.map(String.init) ?? "—")
                    Divider().frame(height: 30).overlay(Theme.border)
                    stat("AC energy", acEnergy.map { String(format: "%.0f kWh", $0) } ?? "—")
                    Divider().frame(height: 30).overlay(Theme.border)
                    stat("DC energy", dcEnergy.map { String(format: "%.0f kWh", $0) } ?? "—")
                }

                if let timestamp = counterSource?.timestamp {
                    Text("Last known values from \(timestamp.formatted(date: .abbreviated, time: .shortened)). These are stored every minute while the BMS is connected.")
                        .font(.caption2)
                        .foregroundStyle(Theme.textTertiary)
                } else {
                    Text("Counters come from the BMS. If you have connected before, historical values appear here after the first snapshot; otherwise connect and wait for the BMS read.")
                        .font(.caption2)
                        .foregroundStyle(Theme.textTertiary)
                }
            }
        }
    }

    private var diagnosticsCard: some View {
        TelemetryCard {
            VStack(alignment: .leading, spacing: 10) {
                CardLabel(text: "TEST")

                Button {
                    store.runChargingTest()
                } label: {
                    Label("Run charging test", systemImage: "bolt.badge.clock")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)
                .tint(Theme.cyan)

                if let report = store.lastReport, report.kind == "charging" {
                    HStack {
                        Text(report.title).font(.subheadline.weight(.semibold))
                        Spacer()
                        Text(report.status.uppercased())
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(report.status == "pass" ? Theme.green : (report.status == "fail" ? Theme.red : Theme.amber))
                    }
                    Text(report.summary)
                        .font(.caption)
                        .foregroundStyle(Theme.textSecondary)
                }
            }
        }
    }

    private func stat(_ title: LocalizedStringKey, _ value: String) -> some View {
        VStack(spacing: 3) {
            CardLabel(text: title)
            Text(value)
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .monospacedDigit()
                .foregroundStyle(Theme.textPrimary)
        }
        .frame(maxWidth: .infinity)
    }
}
