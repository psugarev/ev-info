import SwiftUI

// MARK: - Settings
// Language, OBD2 adapter selection and app info. Tariff/cost editing lives in
// the Costs tab; charging lives in its own tab.

struct SettingsView: View {
    @EnvironmentObject var ble: BLETransport

    @AppStorage("appLanguage") private var appLanguage = "en"

    private var appVersion: String {
        let info = Bundle.main.infoDictionary
        let short = info?["CFBundleShortVersionString"] as? String ?? "—"
        let build = info?["CFBundleVersion"] as? String ?? "—"
        return "\(short) (\(build))"
    }

    var body: some View {
        Form {
            Section("App") {
                Picker("Language", selection: $appLanguage) {
                    Text("English").tag("en")
                    Text("Български").tag("bg")
                }
                .pickerStyle(.segmented)
            }

            Section("OBD2 adapter") {
                LabeledContent("Status", value: ble.statusMessage)
                LabeledContent("Bluetooth", value: ble.state == .poweredOn ? "On" : "Off")

                Button("Rescan for OBD2 adapter") {
                    ble.scan()
                }

                if !ble.discoveredAdapters.isEmpty {
                    ForEach(ble.discoveredAdapters) { adapter in
                        Button {
                            ble.connect(to: adapter.id)
                        } label: {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(adapter.name)
                                    Text("Signal \(adapter.rssi) dBm")
                                        .font(.caption)
                                        .foregroundStyle(Theme.textTertiary)
                                }
                                Spacer()
                                Text("Connect")
                                    .foregroundStyle(Theme.cyan)
                            }
                        }
                    }
                } else if !ble.connected {
                    Text("Scan, then select your OBD2 adapter from nearby BLE devices.")
                        .font(.caption)
                        .foregroundStyle(Theme.textTertiary)
                }

                NavigationLink("View Saved Raw OBD Log") {
                    RawLogView(tripID: nil)
                }
            }

            Section("About") {
                LabeledContent("App", value: "EV Info")
                LabeledContent("Version", value: appVersion)
                LabeledContent("Vehicle", value: "Hyundai Ioniq 5 RWD 2022")
                LabeledContent("Adapter", value: "vLinker iCar Pro BLE 4.0")
            }
        }
        .navigationTitle("Settings")
        .scrollContentBackground(.hidden)
        .background(Theme.background)
        .listRowBackground(Theme.surface)
        .tint(Theme.cyan)
    }
}
