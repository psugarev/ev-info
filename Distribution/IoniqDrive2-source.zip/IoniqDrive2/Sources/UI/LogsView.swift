import SwiftUI
import SwiftData

// MARK: - Logs & Export
// Always-on telemetry log, battery snapshots and diagnostic reports.
// Exports a full JSON bundle and flat CSV tables.

struct LogsView: View {
    @EnvironmentObject private var store: TelemetryStore

    @Query(sort: \TelemetryLogRecord.timestamp, order: .reverse)
    private var logs: [TelemetryLogRecord]

    @Query(sort: \BatterySnapshot.timestamp, order: .reverse)
    private var battery: [BatterySnapshot]

    @Query(sort: \DiagnosticReport.date, order: .reverse)
    private var reports: [DiagnosticReport]

    @State private var jsonURL: URL?
    @State private var csvURL: URL?
    @State private var batteryCSVURL: URL?
    @State private var exportError: String?

    var body: some View {
        List {
            Section("Data") {
                LabeledContent("Telemetry rows", value: "\(logs.count)")
                LabeledContent("Battery snapshots", value: "\(battery.count)")
                LabeledContent("Test reports", value: "\(reports.count)")
            }

            Section("Export") {
                Button("Prepare JSON + CSV") {
                    prepareExports()
                }

                if let jsonURL {
                    ShareLink(item: jsonURL) {
                        Label("Share JSON bundle", systemImage: "doc.text")
                    }
                }
                if let csvURL {
                    ShareLink(item: csvURL) {
                        Label("Share telemetry CSV", systemImage: "tablecells")
                    }
                }
                if let batteryCSVURL {
                    ShareLink(item: batteryCSVURL) {
                        Label("Share battery CSV", systemImage: "tablecells")
                    }
                }

                if let exportError {
                    Text(exportError)
                        .font(.caption)
                        .foregroundStyle(.red)
                }
            }

            Section("Recent telemetry") {
                if logs.isEmpty {
                    Text("No telemetry logged yet.").foregroundStyle(.secondary)
                } else {
                    ForEach(logs.prefix(50)) { record in
                        HStack {
                            Text(record.timestamp, format: .dateTime.hour().minute().second())
                                .font(.caption.monospaced())
                                .foregroundStyle(.secondary)
                            Spacer()
                            if let soc = record.socPercent {
                                Text(String(format: "%.1f %%", soc))
                            }
                            if let power = record.powerKW {
                                Text(String(format: "%.1f kW", power))
                                    .foregroundStyle(power >= 0 ? .blue : .green)
                            }
                        }
                        .font(.caption)
                    }
                }
            }

            Section("Diagnostic reports") {
                if reports.isEmpty {
                    Text("Run a battery or charging test from the Battery screen.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(reports) { report in
                        VStack(alignment: .leading, spacing: 2) {
                            HStack {
                                Text(report.title).font(.subheadline.weight(.semibold))
                                Spacer()
                                Text(report.status.uppercased())
                                    .font(.caption2.weight(.bold))
                                    .foregroundStyle(report.status == "pass" ? .green : (report.status == "fail" ? .red : .orange))
                            }
                            Text(report.summary).font(.caption).foregroundStyle(.secondary)
                            Text(report.date, format: .dateTime.day().month().hour().minute())
                                .font(.caption2)
                                .foregroundStyle(.tertiary)
                        }
                    }
                }
            }
        }
        .navigationTitle("Logs & Export")
        .scrollContentBackground(.hidden)
        .background(Theme.background)
        .listRowBackground(Theme.surface)
        .tint(Theme.cyan)
        .onAppear(perform: prepareExports)
    }

    private func prepareExports() {
        do {
            let json = try ExportService.jsonBundle(telemetry: logs, battery: battery, diagnostics: reports)
            jsonURL = try ExportService.write(
                json,
                filename: ExportService.timestampedName("ev-info-log", ext: "json")
            )
            csvURL = try ExportService.write(
                ExportService.telemetryCSV(logs),
                filename: ExportService.timestampedName("ev-info-telemetry", ext: "csv")
            )
            batteryCSVURL = try ExportService.write(
                ExportService.batteryCSV(battery),
                filename: ExportService.timestampedName("ev-info-battery", ext: "csv")
            )
            exportError = nil
        } catch {
            exportError = "Export failed: \(error.localizedDescription)"
        }
    }
}
