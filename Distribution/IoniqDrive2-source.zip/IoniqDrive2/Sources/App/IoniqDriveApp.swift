import SwiftUI
import SwiftData

// MARK: - IoniqDrive App Entry Point

@main
struct IoniqDriveApp: App {

    // MARK: - Persistent storage

    private static let container: ModelContainer = {
        let schema = Schema([
            TripRecord.self,
            RawOBDFrame.self,
            TelemetryLogRecord.self,
            BatterySnapshot.self,
            DiagnosticReport.self
        ])
        let configuration = ModelConfiguration("IoniqDrive", schema: schema, isStoredInMemoryOnly: false)
        do {
            return try ModelContainer(for: schema, configurations: [configuration])
        } catch {
            print("[IoniqDriveApp] Container init failed, using in-memory fallback: \(error)")
            let fallback = ModelConfiguration(isStoredInMemoryOnly: true)
            return try! ModelContainer(for: schema, configurations: [fallback])
        }
    }()

    // MARK: - Shared state objects

    @AppStorage("appLanguage") private var appLanguage = "en"

    @StateObject private var ble = BLETransport()
    @StateObject private var telemetry = TelemetryEngine()
    @StateObject private var locationManager = LocationManager()
    @StateObject private var recorder: TripRecorder
    @StateObject private var store: TelemetryStore

    @State private var obdSession: OBDSession?

    init() {
        let context = Self.container.mainContext
        _recorder = StateObject(wrappedValue: TripRecorder(modelContext: context, tariffProfile: .load()))
        _store = StateObject(wrappedValue: TelemetryStore(modelContext: context))
    }

    var body: some Scene {
        WindowGroup {
            rootView
                .environmentObject(ble)
                .environmentObject(telemetry)
                .environmentObject(locationManager)
                .environmentObject(recorder)
                .environmentObject(store)
                .environment(\.locale, Locale(identifier: appLanguage))
                .preferredColorScheme(.dark)
                .modelContainer(Self.container)
                .task {
                    bindSessionIfNeeded()
#if DEBUG
                    DemoMode.start(
                        container: Self.container,
                        telemetry: telemetry,
                        ble: ble
                    )
#endif
                }
        }
    }

    @ViewBuilder
    private var rootView: some View {
#if DEBUG
        if let route = DemoMode.route {
            switch route {
            case .drive:
                DashboardView()
            case .battery:
                NavigationStack { BatteryDetailView() }
            case .cells:
                NavigationStack { CellVoltageView() }
            case .charging:
                NavigationStack { ChargingView() }
            case .history:
                NavigationStack { BatteryHistoryView() }
            }
        } else {
            RootTabView()
        }
#else
        RootTabView()
#endif
    }

    // MARK: - Session wiring

    @MainActor
    private func bindSessionIfNeeded() {
        guard obdSession == nil else { return }
        let session = OBDSession(transport: ble)
        telemetry.bind(session: session, location: locationManager)
        recorder.bind(session: session, locationManager: locationManager)
        store.bind(session: session)
        obdSession = session
    }
}

#if DEBUG
// MARK: - Demo Mode
// Screenshot/design harness only. Launch with `-demo` for sample history and
// live values, and optionally `-demoRoute drive|battery|cells|charging|history`
// to open one screen directly. Excluded from Release builds.

private enum DemoRoute: String {
    case drive
    case battery
    case cells
    case charging
    case history
}

private enum DemoMode {
    static var isEnabled: Bool {
        ProcessInfo.processInfo.arguments.contains("-demo")
    }

    static var route: DemoRoute? {
        let arguments = ProcessInfo.processInfo.arguments
        guard let flag = arguments.firstIndex(of: "-demoRoute"),
              arguments.indices.contains(flag + 1) else { return nil }
        return DemoRoute(rawValue: arguments[flag + 1])
    }

    @MainActor
    static func start(container: ModelContainer, telemetry: TelemetryEngine, ble: BLETransport) {
        guard isEnabled else { return }
        ble.applyDemoConnection()
        telemetry.applyDemoSample(liveSample())
        seedHistory(container: container)
    }

    // MARK: History

    private static func seedHistory(container: ModelContainer) {
        // Seed on a background context so the ~1440 inserts do not stall the
        // first frame; @Query observes the store and updates once it is saved.
        Task.detached {
            let context = ModelContext(container)
            let descriptor = FetchDescriptor<BatterySnapshot>()
            if let count = try? context.fetchCount(descriptor), count > 0 { return }

            let now = Date.now
            let minutes = 24 * 60
            for minute in stride(from: minutes, through: 0, by: -1) {
                let date = now.addingTimeInterval(-Double(minute) * 60)
                let hours = Double(minutes - minute) / 60
                context.insert(BatterySnapshot(sample: historySample(at: date, hours: hours)))
            }
            try? context.save()
        }
    }

    private static func historySample(at date: Date, hours: Double) -> TelemetrySample {
        let soc: Double
        let current: Double
        let temperature: Double

        switch hours {
        case ..<6:
            let progress = hours / 6
            soc = 82 - 24 * progress
            current = 48 + 16 * sin(progress * .pi * 2.4)
            temperature = 25 + 6 * progress
        case ..<7:
            soc = 58
            current = 0.3
            temperature = 30
        case ..<9.5:
            let progress = (hours - 7) / 2.5
            soc = 58 + 22 * (1 - pow(1 - progress, 1.6))
            current = -(180 * (1 - 0.78 * progress))
            temperature = 32 + 6 * progress
        default:
            let progress = (hours - 9.5) / 14.5
            soc = 80 - 2 * progress
            current = 0.35
            temperature = 27 - 2 * progress
        }

        var sample = TelemetrySample(timestamp: date)
        let jitter = sin(hours * 9.1) * (hours < 6 ? 3 : 0.05)
        let voltage = 652 + soc * 0.78 + sin(hours * 5.7) * 0.8
        let packCurrent = current + jitter

        sample.socPercent = soc + sin(hours * 3.1) * 0.05
        sample.batteryVoltageV = voltage
        sample.batteryCurrentA = packCurrent
        sample.batteryPowerKW = voltage * packCurrent / 1_000
        sample.batteryTemperatureC = temperature
        sample.batteryMinTemperatureC = temperature - 2
        sample.batteryInletTemperatureC = temperature - 4
        sample.cellVoltageMaxV = 3.55 + soc * 0.0015 + 0.007
        sample.cellVoltageMinV = 3.55 + soc * 0.0015 - 0.005
        sample.sohPercent = 98.6
        sample.remainingEnergyKWh = 74 * soc / 100
        sample.auxiliaryVoltageV = 12.58 + sin(hours * 2.3) * 0.05
        sample.auxiliaryCurrentA = 0.6
        sample.auxiliarySOCPercent = 84
        sample.isCharging = hours >= 7 && hours < 9.5
        sample.normalChargeCount = 148
        sample.quickChargeCount = 67
        sample.normalChargeEnergyKWh = 8_120
        sample.quickChargeEnergyKWh = 4_430
        sample.odometerKm = 34_218 + max(0, 24 * (hours < 9.5 ? 0 : 1))
        sample.tirePressuresBar = [2.41, 2.52, 2.38, 2.48]
        sample.tireTemperaturesC = [23, 26, 22, 24]
        return sample
    }

    // MARK: Live values

    private static func liveSample() -> TelemetrySample {
        var sample = TelemetrySample(timestamp: .now)
        sample.speedKmh = 0
        sample.socPercent = 78.4
        sample.batteryVoltageV = 707.5
        sample.batteryCurrentA = -54.2
        sample.batteryPowerKW = 707.5 * -54.2 / 1_000
        sample.batteryTemperatureC = 31
        sample.batteryMinTemperatureC = 29
        sample.batteryInletTemperatureC = 27
        sample.sohPercent = 98.6
        sample.remainingEnergyKWh = 58.0
        sample.auxiliaryVoltageV = 12.62
        sample.auxiliaryCurrentA = 0.8
        sample.auxiliarySOCPercent = 84
        sample.normalChargeCount = 148
        sample.quickChargeCount = 67
        sample.normalChargeEnergyKWh = 8_120
        sample.quickChargeEnergyKWh = 4_430
        sample.isCharging = true
        sample.odometerKm = 34_218
        sample.ambientTemperatureC = 18

        var voltages = [Double?](repeating: nil, count: 192)
        for index in 0..<192 {
            let wave = sin(Double(index) * 0.55) * 0.004 + cos(Double(index) * 0.21) * 0.003
            voltages[index] = 3.664 + wave
        }
        // Three deliberate outliers so the grid and spread chart have a story.
        voltages[41] = 3.628
        voltages[97] = 3.641
        voltages[150] = 3.648
        sample.cellVoltages = voltages
        sample.cellVoltageMaxV = voltages.compactMap { $0 }.max()
        sample.cellVoltageMinV = voltages.compactMap { $0 }.min()

        sample.tirePressuresBar = [2.41, 2.52, 2.38, 2.48]
        sample.tireTemperaturesC = [23, 26, 22, 24]
        return sample
    }
}
#endif
